<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Lecture</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body style="font-family:Arial, Helvetica, sans-serif;">
    <br><br><br><br><br><br><br><br><br>
    <div class="container">
        <form action="details.php" method="get">
            <h1>Enter Details</h1>
            <p>Name</p>
            <input type="text" name="name" placeholder="Enter your name">
            <p>Surname</p>
            <input type="text" name="surname" placeholder="Enter your surname">
            <p>Gross Income</p>
            <input type="text" name="gross" placeholder="Enter your gross income">
            <p>Tax</p>
            <input type="text" name="tax" placeholder="Enter your tax">
            <br><br><br>
            <button>Submit</button>
        </form>

    </div>
</body>

</html>