<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Lecture</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body style="font-family:Arial, Helvetica, sans-serif;">
    <br><br><br><br><br><br><br><br><br>
    <div class="container">
        <form action="post.php" method="post">
            <h1>Log In</h1>
            <input type="text" name="email" placeholder="Enter your email">
            <br><br>
            <input type="password" name="pass" placeholder="Enter your password">
            <br><br>
            <button>Sign In</button>
        </form>

    </div>
</body>

</html>