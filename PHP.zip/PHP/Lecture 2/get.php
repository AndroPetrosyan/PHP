<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>PHP Lecture</title>
    <link rel="stylesheet" href="styles.css">
</head>

<body style="font-family:Arial, Helvetica, sans-serif;">
    <br><br><br><br><br><br><br><br><br>
    <div class="getContainer">
        <?php
        foreach ($_GET as $email => $pass) {
            echo "<p>$email: $pass</p>";
        }
        ?>
    </div>
</body>

</html>